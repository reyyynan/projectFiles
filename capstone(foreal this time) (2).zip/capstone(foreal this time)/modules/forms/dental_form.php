<?php
session_start();
include __DIR__ . '/../../config/database.php';


// Redirect to login if not authenticated
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");
    exit();
}

$success_message = '';
$error_message = '';

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = trim($_POST['student_id'] ?? '');
    $first_name = trim($_POST['first_name'] ?? '');
    $middle_name = trim($_POST['middle_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $date_of_birth = trim($_POST['date_of_birth'] ?? '');
    $sex = trim($_POST['sex'] ?? '');
    $program = trim($_POST['program'] ?? '');
    $year_level = trim($_POST['year_level'] ?? '');

    // ✅ Step 1: Check if patient already exists by student_id
    $stmt = $conn->prepare("SELECT id FROM patients WHERE student_id = ?");
    $stmt->bind_param("s", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Patient already exists, fetch ID
        $row = $result->fetch_assoc();
        $patient_id = $row['id'];
    } else {
        // ✅ Step 2: Create new patient if not found
        $stmt = $conn->prepare("INSERT INTO patients 
            (student_id, first_name, middle_name, last_name, date_of_birth, sex, program, year_level) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssss", $student_id, $first_name, $middle_name, $last_name, $date_of_birth, $sex, $program, $year_level);

        if ($stmt->execute()) {
            $patient_id = $conn->insert_id;
        } else {
            $error_message = "Error creating patient record: " . $conn->error;
        }
    }

    // ✅ Step 3: Create a new medical record entry
    if (!empty($patient_id)) {
        $stmt = $conn->prepare("INSERT INTO medical_records (patient_id, record_type, examination_date, physician_name)
                                VALUES (?, 'dental_exam', ?, ?)");
        $examination_date = date('Y-m-d');
        $physician_name = $_POST['dentist_name'] ?? '';
        $stmt->bind_param("iss", $patient_id, $examination_date, $physician_name);

        if ($stmt->execute()) {
            $record_id = $conn->insert_id;

            // ✅ Step 4: Insert dental exam details
            $stmt = $conn->prepare("
                INSERT INTO dental_exams
                (record_id, dentition_status, treatment_needs, periodontal_screening, occlusion, appliances, tmd_status, remarks, dentist_name, license_no, dental_chart_data, verification_status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
            ");

            $dentition_status = $_POST['status_grid'] ?? '';
            $treatment_needs = $_POST['treatment_nature'][0] ?? '';
            $periodontal_screening = isset($_POST['gingivitis']) ? 'Gingivitis' : (isset($_POST['early_periodontitis']) ? 'Early Periodontitis' : (isset($_POST['moderate_periodontitis']) ? 'Moderate Periodontitis' : (isset($_POST['advanced_periodontitis']) ? 'Advanced Periodontitis' : '')));
            $occlusion = isset($_POST['class_molar']) ? 'Class(Molar)' : (isset($_POST['overjet']) ? 'Overjet' : (isset($_POST['overbite']) ? 'Overbite' : (isset($_POST['crossbite']) ? 'Crossbite' : (isset($_POST['midline_deviation']) ? 'Midline Deviation' : ''))));
            $appliances = isset($_POST['orthodontic']) ? 'Orthodontic' : (isset($_POST['stayplate']) ? 'Stayplate' : (isset($_POST['appliance_others']) ? 'Others' : ''));
            $tmd_status = isset($_POST['clenching']) ? 'Clenching' : (isset($_POST['clicking']) ? 'Clicking' : (isset($_POST['trismus']) ? 'Trismus' : (isset($_POST['muscle_spasm']) ? 'Muscle Spasm' : '')));
            $remarks = $_POST['remarks'] ?? '';
            $dentist_name = $_POST['dentist_name'] ?? '';
            $license_no = $_POST['license_no'] ?? '';
            $dental_chart_data = $_POST['dental_chart_data'] ?? '';

            $stmt->bind_param(
                "issssssssss",
                $record_id,
                $dentition_status,
                $treatment_needs,
                $periodontal_screening,
                $occlusion,
                $appliances,
                $tmd_status,
                $remarks,
                $dentist_name,
                $license_no,
                $dental_chart_data
            );

            if ($stmt->execute()) {
                // ✅ Step 5: Redirect to verification page
                $success_message = "Form successfully submitted! Please wait for admin verification.";
            } else {
                $error_message = "Error saving dental exam data: " . $conn->error;
            }
        } else {
            $error_message = "Error creating medical record: " . $conn->error;
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dental Examination Form - BSU Clinic Records</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
    <link rel="stylesheet" href="../../assets/css/style.css">
    <style>
        .tooth-chart {
            display: grid;
            grid-template-columns: repeat(16, 1fr);
            gap: 2px;
            margin: 20px 0;
        }
        .tooth {
            border: 1px solid #ccc;
            padding: 5px;
            text-align: center;
            font-size: 12px;
            cursor: pointer;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f8f9fa;
        }
        .tooth.selected {
            background-color: #ffcccc;
        }
        .tooth-legend {
            margin-top: 10px;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }
        .legend-item {
            display: flex;
            align-items: center;
            margin-right: 15px;
            cursor: pointer;
            padding: 5px;
            border-radius: 4px;
        }
        .legend-item.active {
            background-color: #e3f2fd;
            border: 1px solid #2196f3;
        }
        .legend-color {
            width: 20px;
            height: 20px;
            margin-right: 5px;
            border-radius: 2px;
        }
        .legend-text {
            font-size: 12px;
        }
    </style>
</head>
<body>
   
    
    <div class="bg-gray-100 min-h-screen py-8">
        <div class="max-w-5xl mx-auto px-4 mb-6">
            <a href="/capstone(foreal this time)/user_dashboard.php" class="inline-flex items-center gap-2 bg-blue-600 text-white font-semibold px-4 py-2 rounded-lg shadow hover:bg-blue-700 transition">
                <i class="bi bi-arrow-left"></i> Back to Dashboard
            </a>
        </div>
        <div class="max-w-5xl mx-auto px-4">
            <div class="bg-white shadow rounded-lg">
                <div class="bg-gradient-to-r from-blue-700 via-blue-600 to-blue-500 text-white px-8 py-6 rounded-t-lg">
                    <h4 class="text-2xl font-bold mb-2">DENTAL EXAMINATION FORM</h4>
                    <p class="mb-0 text-sm">Reference No.: BatStateU-FO-HSD-18 | Effectivity Date: March 12, 2024 | Revision No.: 03</p>
                </div>
                <div class="px-8 py-8">
                    <?php if (!empty($success_message)): ?>
                        <div class="alert alert-success"><?php echo $success_message; ?></div>
                    <?php endif; ?>
                    <?php if (!empty($error_message)): ?>
                        <div class="alert alert-danger"><?php echo $error_message; ?></div>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                        <!-- Patient Information Section -->
                     <!-- Patient Information Section -->
<h5 class="text-lg font-bold text-blue-700 mb-4">Patient Information</h5>

<div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
    <div>
        <label for="student_id" class="block font-medium mb-1">Student ID</label>
        <input type="text" class="w-full rounded border border-gray-300 px-3 py-2" id="student_id" name="student_id" required>
    </div>
    <div>
        <label for="program" class="block font-medium mb-1">Program</label>
        <input type="text" class="w-full rounded border border-gray-300 px-3 py-2" id="program" name="program" required>
    </div>
</div>

<div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
    <div>
        <label for="first_name" class="block font-medium mb-1">First Name</label>
        <input type="text" class="w-full rounded border border-gray-300 px-3 py-2" id="first_name" name="first_name" required>
    </div>
    <div>
        <label for="middle_name" class="block font-medium mb-1">Middle Name</label>
        <input type="text" class="w-full rounded border border-gray-300 px-3 py-2" id="middle_name" name="middle_name">
    </div>
    <div>
        <label for="last_name" class="block font-medium mb-1">Last Name</label>
        <input type="text" class="w-full rounded border border-gray-300 px-3 py-2" id="last_name" name="last_name" required>
    </div>
</div>

<div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
    <div>
        <label for="date_of_birth" class="block font-medium mb-1">Date of Birth</label>
        <input type="date" class="w-full rounded border border-gray-300 px-3 py-2" id="date_of_birth" name="date_of_birth" required>
    </div>
    <div>
        <label class="block font-medium mb-1">Sex</label>
        <select name="sex" id="sex" class="w-full rounded border border-gray-300 px-3 py-2" required>
            <option value="">Select</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
        </select>
    </div>
    <div>
        <label for="year_level" class="block font-medium mb-1">Year Level</label>
        <input type="text" class="w-full rounded border border-gray-300 px-3 py-2" id="year_level" name="year_level" required>
    </div>
</div>


                        <!-- Dental Chart -->
                        <h5 class="mt-8 mb-4 text-lg font-bold text-blue-700">Dental Chart</h5>
                        <div class="mb-6">
                            <div class="tooth-chart">
                                <!-- Upper Jaw -->
                                <div class="mb-4">
                                    <h6 class="text-center font-semibold mb-2">Upper Jaw (Maxillary)</h6>
                                    <div class="grid grid-cols-16 gap-1 justify-center">
                                        <div class="tooth" data-tooth="18">18</div>
                                        <div class="tooth" data-tooth="17">17</div>
                                        <div class="tooth" data-tooth="16">16</div>
                                        <div class="tooth" data-tooth="15">15</div>
                                        <div class="tooth" data-tooth="14">14</div>
                                        <div class="tooth" data-tooth="13">13</div>
                                        <div class="tooth" data-tooth="12">12</div>
                                        <div class="tooth" data-tooth="11">11</div>
                                        <div class="tooth" data-tooth="21">21</div>
                                        <div class="tooth" data-tooth="22">22</div>
                                        <div class="tooth" data-tooth="23">23</div>
                                        <div class="tooth" data-tooth="24">24</div>
                                        <div class="tooth" data-tooth="25">25</div>
                                        <div class="tooth" data-tooth="26">26</div>
                                        <div class="tooth" data-tooth="27">27</div>
                                        <div class="tooth" data-tooth="28">28</div>
                                    </div>
                                </div>
                                <!-- Lower Jaw -->
                                <div>
                                    <h6 class="text-center font-semibold mb-2">Lower Jaw (Mandibular)</h6>
                                    <div class="grid grid-cols-16 gap-1 justify-center">
                                        <div class="tooth" data-tooth="48">48</div>
                                        <div class="tooth" data-tooth="47">47</div>
                                        <div class="tooth" data-tooth="46">46</div>
                                        <div class="tooth" data-tooth="45">45</div>
                                        <div class="tooth" data-tooth="44">44</div>
                                        <div class="tooth" data-tooth="43">43</div>
                                        <div class="tooth" data-tooth="42">42</div>
                                        <div class="tooth" data-tooth="41">41</div>
                                        <div class="tooth" data-tooth="31">31</div>
                                        <div class="tooth" data-tooth="32">32</div>
                                        <div class="tooth" data-tooth="33">33</div>
                                        <div class="tooth" data-tooth="34">34</div>
                                        <div class="tooth" data-tooth="35">35</div>
                                        <div class="tooth" data-tooth="36">36</div>
                                        <div class="tooth" data-tooth="37">37</div>
                                        <div class="tooth" data-tooth="38">38</div>
                                    </div>
                                </div>
                            </div>
                            <div class="tooth-legend">
                                <div class="legend-item active">
                                    <div class="legend-color" style="background-color: #dc3545;"></div>
                                    <span class="legend-text">Dental Caries</span>
                                </div>
                                <div class="legend-item">
                                    <div class="legend-color" style="background-color: #ffc107;"></div>
                                    <span class="legend-text">Missing</span>
                                </div>
                                <div class="legend-item">
                                    <div class="legend-color" style="background-color: #28a745;"></div>
                                    <span class="legend-text">Filled</span>
                                </div>
                                <div class="legend-item">
                                    <div class="legend-color" style="background-color: #17a2b8;"></div>
                                    <span class="legend-text">For Extraction</span>
                                </div>
                                <div class="legend-item">
                                    <div class="legend-color" style="background-color: #6c757d;"></div>
                                    <span class="legend-text">Impacted</span>
                                </div>
                            </div>
                        </div>

                        <!-- Treatment Record -->
                        <h5 class="mt-8 mb-4 text-lg font-bold text-blue-700">Treatment Record</h5>
                        <div class="overflow-x-auto mb-6">
                            <table class="min-w-full border border-gray-300 text-center">
                                <thead class="bg-gray-100">
                                    <tr>
                                        <th>Date</th>
                                        <th>Tooth No.</th>
                                        <th>Nature of Operation</th>
                                        <th>Dentist</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><input type="date" class="w-full border rounded px-2 py-1" name="treatment_date[]"></td>
                                        <td><input type="text" class="w-full border rounded px-2 py-1" name="treatment_tooth[]"></td>
                                        <td><input type="text" class="w-full border rounded px-2 py-1" name="treatment_nature[]"></td>
                                        <td><input type="text" class="w-full border rounded px-2 py-1" name="treatment_dentist[]"></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <!-- Index Tables -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                            <div>
                                <h6 class="font-bold mb-2">Temporary Teeth d.f.t.</h6>
                                <table class="min-w-full border border-gray-300 text-center mb-2">
                                    <thead class="bg-gray-100">
                                        <tr><th>Index d.f.t.</th><th>1st</th><th>2nd</th><th>3rd</th><th>4th</th><th>5th</th><th>6th</th></tr>
                                    </thead>
                                    <tbody>
                                        <tr><td>No. T/Decayed</td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
                                        <tr><td>No. T/Filled</td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
                                        <tr><td>Total d.f.t.</td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
                                    </tbody>
                                </table>
                            </div>
                            <div>
                                <h6 class="font-bold mb-2">Permanent Teeth D.M.F.T.</h6>
                                <table class="min-w-full border border-gray-300 text-center mb-2">
                                    <thead class="bg-gray-100">
                                        <tr><th>Index D.M.F.T.</th><th>1st</th><th>2nd</th><th>3rd</th><th>4th</th></tr>
                                    </thead>
                                    <tbody>
                                        <tr><td>D</td><td></td><td></td><td></td><td></td></tr>
                                        <tr><td>M</td><td></td><td></td><td></td><td></td></tr>
                                        <tr><td>F</td><td></td><td></td><td></td><td></td></tr>
                                        <tr><td>Total DMF</td><td></td><td></td><td></td><td></td></tr>
                                        <tr><td>Total Sound Tooth</td><td></td><td></td><td></td><td></td></tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- Legend -->
                        <h5 class="mt-8 mb-4 text-lg font-bold text-blue-700">Legend</h5>
                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 text-sm">
                            <div>X – Carious tooth indicated for extraction</div>
                            <div>C – Carious tooth indicated for filling</div>
                            <div>RF – Root Fragment</div>
                            <div>M – Missing</div>
                            <div>Im – Impacted</div>
                            <div>Un – Unerupted</div>
                            <div>√ – Present Tooth</div>
                            <div>Cm – Congenitally Missing</div>
                            <div>Sp – Supernumerary</div>
                            <div>JC – Jacket Crown</div>
                            <div>Am – Amalgam</div>
                            <div>Comp – Composite</div>
                            <div>TF – Temporary Filling</div>
                            <div>S – Sealant</div>
                            <div>In – Inlay</div>
                            <div>AB – Abutment</div>
                            <div>P – Pontic</div>
                            <div>RPD – Removable Partial Denture</div>
                            <div>CD – Complete Denture</div>
                            <div>FB – Fixed Bridge</div>
                        </div>

                        <!-- Periodontal Screening, Occlusion, Appliances, TMD -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                            <div>
                                <h6 class="font-bold mb-2">Periodontal Screening</h6>
                                <div class="flex flex-col gap-2">
                                    <label><input type="checkbox" name="gingivitis" value="1"> Gingivitis</label>
                                    <label><input type="checkbox" name="early_periodontitis" value="1"> Early Periodontitis</label>
                                    <label><input type="checkbox" name="moderate_periodontitis" value="1"> Moderate Periodontitis</label>
                                    <label><input type="checkbox" name="advanced_periodontitis" value="1"> Advanced Periodontitis</label>
                                </div>
                            </div>
                            <div>
                                <h6 class="font-bold mb-2">Occlusion</h6>
                                <div class="flex flex-col gap-2">
                                    <label><input type="checkbox" name="class_molar" value="1"> Class(Molar)</label>
                                    <label><input type="checkbox" name="overjet" value="1"> Overjet</label>
                                    <label><input type="checkbox" name="overbite" value="1"> Overbite</label>
                                    <label><input type="checkbox" name="crossbite" value="1"> Crossbite</label>
                                    <label><input type="checkbox" name="midline_deviation" value="1"> Midline Deviation</label>
                                </div>
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                            <div>
                                <h6 class="font-bold mb-2">Appliances</h6>
                                <div class="flex flex-col gap-2">
                                    <label><input type="checkbox" name="orthodontic" value="1"> Orthodontic</label>
                                    <label><input type="checkbox" name="stayplate" value="1"> Stayplate</label>
                                    <label><input type="checkbox" name="appliance_others" value="1"> Others</label>
                                </div>
                            </div>
                            <div>
                                <h6 class="font-bold mb-2">TMD</h6>
                                <div class="flex flex-col gap-2">
                                    <label><input type="checkbox" name="clenching" value="1"> Clenching</label>
                                    <label><input type="checkbox" name="clicking" value="1"> Clicking</label>
                                    <label><input type="checkbox" name="trismus" value="1"> Trismus</label>
                                    <label><input type="checkbox" name="muscle_spasm" value="1"> Muscle Spasm</label>
                                </div>
                            </div>
                        </div>

                        <!-- Dental Chart Data (Hidden) -->
                        <input type="hidden" id="dental_chart_data" name="dental_chart_data" value="">

                        <!-- Remarks -->
                        <div class="mb-6">
                            <label for="remarks" class="block font-medium mb-1">Remarks</label>
                            <textarea class="w-full rounded border border-gray-300 px-3 py-2" id="remarks" name="remarks" rows="2"></textarea>
                        </div>

                        <!-- Dentist Signature -->
                        <div class="mb-6">
                            <label for="dentist_signature" class="block font-medium mb-1">Dentist Signature</label>
                            <input type="text" class="w-full rounded border border-gray-300 px-3 py-2" id="dentist_signature" name="dentist_signature">
                            <label for="license_no" class="block font-medium mb-1 mt-2">License No.</label>
                            <input type="text" class="w-full rounded border border-gray-300 px-3 py-2" id="license_no" name="license_no">
                        </div>
                       
                        <!-- Certification Section -->
                        <h5 class="mt-8 mb-4 text-lg font-bold text-blue-700">Certification</h5>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                            <div>
                                <p class="mb-2">I hereby certify that the above information given are true and correct as to the best of my knowledge.</p>
                                <div class="mb-3">
                                    <label for="student_signature" class="block font-medium mb-1">Signature over Printed Name of Student</label>
                                    <input type="text" class="w-full rounded border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" id="student_signature" name="student_signature" required>
                                </div>
                                <div class="mb-3">
                                    <label for="student_date" class="block font-medium mb-1">Date</label>
                                    <input type="date" class="w-full rounded border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" id="student_date" name="student_date" value="<?php echo date('Y-m-d'); ?>" required>
                                </div>
                            </div>
                            <div>
                                <p class="mb-2">Examined by:</p>
                                <div class="mb-3">
                                    <label for="dentist_name" class="block font-medium mb-1">Signature over Printed Name of Dentist</label>
                                    <input type="text" class="w-full rounded border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" id="dentist_name" name="dentist_name" required>
                                </div>
                                <div class="mb-3">
                                    <label for="license_no" class="block font-medium mb-1">License No.</label>
                                    <input type="text" class="w-full rounded border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" id="license_no" name="license_no" required>
                                </div>
                                <div class="mb-3">
                                    <label for="dentist_date" class="block font-medium mb-1">Date</label>
                                    <input type="date" class="w-full rounded border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" id="dentist_date" name="dentist_date" value="<?php echo date('Y-m-d'); ?>" required>
                                </div>
                            </div>
                        </div>
                        <!-- Data Privacy Act Section -->
                        <div class="border-2 border-blue-400 rounded-lg bg-white shadow p-4 mb-6">
                            <p class="text-xs text-gray-600 mb-2">Pursuant to Republic Act No. 10173, also known as the Data Privacy Act of 2012, the Batangas State University, the National Engineering University, recognizes its commitment to protect and respect the privacy of its customers and/or stakeholders and ensure that all information collected from them are all processed in accordance with the principles of transparency, legitimate purpose and proportionality mandated under the Data Privacy Act of 2012.</p>
                        </div>
                            
                        <div class="flex flex-col md:flex-row gap-4 justify-end mt-8">
                            <button type="submit" class="bg-blue-600 text-white font-semibold px-6 py-2 rounded-lg shadow hover:bg-blue-700 transition">Save Form</button>
                            <!-- <button type="button" class="bg-green-500 text-white font-semibold px-6 py-2 rounded-lg shadow hover:bg-green-600 transition" id="generateQR">Generate QR Code</button> -->
                            <button type="button" class="bg-gray-400 text-white font-semibold px-6 py-2 rounded-lg shadow hover:bg-gray-500 transition" onclick="window.print()">Print Form</button>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <!
    

    
    <script src="../../assets/js/jquery.min.js"></script>
    <script src="../../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../../assets/js/qrcode.min.js"></script>
    <script>
        $(document).ready(function() {
            // Tooth chart interaction
            let currentTool = 'caries';
            let dentalChartData = {};

            $('.tooth').click(function() {
                const toothId = $(this).data('tooth');
                const isSelected = $(this).hasClass('selected');

                // If clicking on a tooth that's already selected with the current tool, deselect it
                if (isSelected && dentalChartData[toothId] === currentTool) {
                    $(this).removeClass('selected');
                    $(this).css('background-color', '#f8f9fa');
                    delete dentalChartData[toothId];
                } else {
                    // Remove previous selection for this tooth
                    $(this).removeClass('selected');
                    $(this).addClass('selected');

                    // Apply new condition
                    switch(currentTool) {
                        case 'caries':
                            $(this).css('background-color', '#dc3545');
                            dentalChartData[toothId] = {condition: 'caries'};
                            break;
                        case 'missing':
                            $(this).css('background-color', '#ffc107');
                            dentalChartData[toothId] = {condition: 'missing'};
                            break;
                        case 'filled':
                            $(this).css('background-color', '#28a745');
                            dentalChartData[toothId] = {condition: 'filled'};
                            break;
                        case 'extraction':
                            $(this).css('background-color', '#17a2b8');
                            dentalChartData[toothId] = {condition: 'extraction'};
                            break;
                        case 'impacted':
                            $(this).css('background-color', '#6c757d');
                            dentalChartData[toothId] = {condition: 'impacted'};
                            break;
                    }
                }

                $('#dental_chart_data').val(JSON.stringify(dentalChartData));
                console.log('Dental Chart Data:', dentalChartData); // Debug log
            });

            $('.legend-item').click(function() {
                $('.legend-item').removeClass('active');
                $(this).addClass('active');
                const legendText = $(this).find('.legend-text').text().toLowerCase();
                switch(legendText) {
                    case 'dental caries': currentTool = 'caries'; break;
                    case 'missing': currentTool = 'missing'; break;
                    case 'filled': currentTool = 'filled'; break;
                    case 'for extraction': currentTool = 'extraction'; break;
                    case 'impacted': currentTool = 'impacted'; break;
                }
            });

            // Generate QR code (same logic as history_form.php)
            $('#generateQR').click(function() {
                var studentId = $('#student_id').val();
                var name = $('#first_name').val() + ' ' + $('#last_name').val();
                var formType = 'Dental Examination Form';
                var date = $('#date_of_examination').val();
                if (!studentId || !name) {
                    alert('Please fill in student ID and name fields first.');
                    return;
                }
                var qrData = 'Student ID: ' + studentId + '\nName: ' + name + '\nForm: ' + formType + '\nDate: ' + date;
                $('#qrcode').empty();
                new QRCode(document.getElementById("qrcode"), {
                    text: qrData,
                    width: 200,
                    height: 200
                });
                $('#qrCodeModal').modal('show');
            });

            // Download QR code
            $('#downloadQR').click(function() {
                var canvas = document.querySelector("#qrcode canvas");
                var image = canvas.toDataURL("image/png").replace("image/png", "image/octet-stream");
                var link = document.createElement('a');
                link.download = 'qrcode.png';
                link.href = image;
                link.click();
            });
        });
    </script>
      <?php if (!empty($success_message)): ?>
<script>
    alert("Form successfully submitted! Please wait for admin verification.");
    window.location.href = "/capstone(foreal this time)/user_dashboard.php";
</script>
<?php endif; ?>
</body>
</html>