<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
include __DIR__ . '/../config/database.php';

// Redirect to login if not authenticated
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");
    exit();
}

$success_message = '';
$error_message = '';

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get patient ID or create new patient
    $patient_id = isset($_POST['patient_id']) ? $_POST['patient_id'] : null;
    
    if (!$patient_id) {
        // Check if student already exists
        $check = $conn->prepare("SELECT id FROM patients WHERE student_id = ?");
        $check->bind_param("s", $_POST['student_id']);
        $check->execute();
        $check_result = $check->get_result();

        if ($check_result->num_rows > 0) {
            // Student already exists — reuse their patient_id
            $existing_patient = $check_result->fetch_assoc();
            $patient_id = $existing_patient['id'];
        } else {
            // Create new patient
            $stmt = $conn->prepare("INSERT INTO patients (student_id, first_name, middle_name, last_name, date_of_birth, sex, program, year_level) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssss", $_POST['student_id'], $_POST['first_name'], $_POST['middle_name'], $_POST['last_name'], $_POST['date_of_birth'], $_POST['sex'], $_POST['program'], $_POST['year_level']);
            if ($stmt->execute()) {
                $patient_id = $conn->insert_id;
            } else {
                $error_message = "Error creating patient record: " . $conn->error;
            }
        }
    }
    
    if ($patient_id) {
        // Create medical record entry
        $stmt = $conn->prepare("INSERT INTO medical_records (patient_id, record_type, examination_date, physician_name) VALUES (?, 'medical_exam', ?, ?)");
        $examination_date = date('Y-m-d');
        $physician_name = $_POST['physician_name'] ?? '';
        $stmt->bind_param("iss", $patient_id, $examination_date, $physician_name);
        
        if ($stmt->execute()) {
            $record_id = $conn->insert_id;
            
            // Insert medical exam data
            $stmt = $conn->prepare("
                INSERT INTO medical_exams (
                    record_id, height, weight, bmi, blood_pressure, pulse_rate, temperature,
                    vision_status, physical_findings, diagnostic_results, classification,
                    recommendations, physician_name, license_no
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");

            // Get form data with proper defaults
            $height = $_POST['height_cert'] ?? '';
            $weight = $_POST['weight_cert'] ?? '';
            $bmi = $_POST['bmi'] ?? '';
            $blood_pressure = $_POST['blood_pressure'] ?? '';
            $pulse_rate = $_POST['pulse_rate'] ?? '';
            $temperature = $_POST['temperature'] ?? '';
            $vision_status = $_POST['vision_status'] ?? '';
            $physical_findings = $_POST['physical_findings'] ?? '';
            $diagnostic_results = $_POST['diagnostic_results'] ?? '';
            $classification = $_POST['classification'] ?? '';
            $recommendations = $_POST['recommendations'] ?? '';
            $physician_name = $_POST['physician_name'] ?? '';
            $license_no = $_POST['license_no'] ?? '';

            $stmt->bind_param(
                "isssssssssssss",
                $record_id,
                $height,
                $weight,
                $bmi,
                $blood_pressure,
                $pulse_rate,
                $temperature,
                $vision_status,
                $physical_findings,
                $diagnostic_results,
                $classification,
                $recommendations,
                $physician_name,
                $license_no
            );

            if ($stmt->execute()) {
                // Generate QR code for this record
                $qr_data = "record_id=" . $record_id . "&type=medical_exam&date=" . $examination_date;
                $qr_code = base64_encode($qr_data);

                // Update patient with QR code
                $stmt = $conn->prepare("UPDATE patients SET qr_code = ? WHERE id = ?");
                $stmt->bind_param("si", $qr_code, $patient_id);
                $stmt->execute();

                // Add to analytics data
                $stmt = $conn->prepare("INSERT INTO analytics_data (data_type, data_value, data_label, data_date) VALUES ('medical_exam', 1, 'New Medical Exam', CURDATE())");
                $stmt->execute();

                // Log user activity
                $activity_type = 'medical_exam';
                $description = 'Medical Examination Form Submitted';
                
                $activity_stmt = $conn->prepare("INSERT INTO user_activities (user_id, activity_type, activity_description) VALUES (?, ?, ?)");
                $activity_stmt->bind_param("iss", $_SESSION['user_id'], $activity_type, $description);
                $activity_stmt->execute();
                $activity_stmt->close();

                $success_message = "Medical examination form successfully submitted! Please wait for admin verification.";
            } else {
                $error_message = "Error saving medical exam data: " . $conn->error;
            }
        } else {
            $error_message = "Error creating medical record: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medical Examination Form - BSU Clinic Records</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../assets/css/style.css">
    <style>
        /* Disabled physician-only sections */
        .physician-only {
            background-color: #f8f9fa !important;
            border: 1px solid #e9ecef !important;
            cursor: not-allowed !important;
        }
        
        .physician-only input,
        .physician-only textarea,
        .physician-only select {
            background-color: #f8f9fa !important;
            cursor: not-allowed !important;
            color: #6c757d !important;
        }
        
        .physician-only input[type="checkbox"],
        .physician-only input[type="radio"] {
            cursor: not-allowed !important;
            opacity: 0.6;
        }
        
        .disabled-overlay {
            position: relative;
        }
        
        .disabled-overlay::after {
            content: "For Physician Use Only";
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: rgba(0, 0, 0, 0.8);
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            font-weight: bold;
            z-index: 10;
            display: none;
        }
        
        .disabled-overlay:hover::after {
            display: block;
        }
        
        .disabled-label {
            color: #6c757d !important;
            font-style: italic;
        }
        
        .student-section {
            background-color: #f0f9ff !important;
            border-left: 4px solid #3b82f6 !important;
        }
    </style>
</head>
<body>
    
    <div class="bg-gray-100 min-h-screen py-8">
        <div class="max-w-5xl mx-auto px-4 mb-6">
            <a href="/capstone(foreal this time)/user_dashboard.php" class="inline-block bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-2 rounded-lg shadow mb-4 transition">Back to Dashboard</a>
        </div>
        <div class="max-w-5xl mx-auto px-4">
            <div class="bg-white rounded-lg shadow-lg">
                <div class="bg-gradient-to-r from-blue-700 via-blue-600 to-blue-500 text-white px-8 py-6 rounded-t-lg">
                    <h2 class="text-2xl font-bold mb-2">PRE-EMPLOYMENT/OJT MEDICAL EXAMINATION FORM</h2>
                    <p class="text-base">Reference No.: BatStateU-FO-HSD-04 | Effectivity Date: March 12, 2024 | Revision No.: 02</p>
                </div>
                <div class="px-8 py-8">
                    <?php if (!empty($success_message)): ?>
                        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-2 rounded mb-4 text-sm">
                            <?php echo $success_message; ?>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($error_message)): ?>
                        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-2 rounded mb-4 text-sm">
                            <?php echo $error_message; ?>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" id="medicalForm">
                        <!-- Personal Info - Student Section -->
                        <div class="student-section rounded-lg p-6 mb-8">
                            <h3 class="text-lg font-bold text-blue-700 mb-4">Personal Information</h3>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                                <div>
                                    <label class="block text-xs font-semibold">Last Name</label>
                                    <input type="text" name="last_name" class="w-full rounded border border-gray-300 px-2 py-1 text-xs" required>
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold">Student ID</label>
                                    <input type="text" name="student_id" class="w-full rounded border border-gray-300 px-2 py-1 text-xs" required>
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold">Date</label>
                                    <input type="date" name="date_of_examination" class="w-full rounded border border-gray-300 px-2 py-1 text-xs" value="<?php echo date('Y-m-d'); ?>" required>
                                </div>
                            </div>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                                <div>
                                    <label class="block text-xs font-semibold">First Name</label>
                                    <input type="text" name="first_name" class="w-full rounded border border-gray-300 px-2 py-1 text-xs" required>
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold">Birthday</label>
                                    <input type="date" name="date_of_birth" class="w-full rounded border border-gray-300 px-2 py-1 text-xs" required>
                                </div>
                            </div>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                                <div>
                                    <label class="block text-xs font-semibold">Middle Name</label>
                                    <input type="text" name="middle_name" class="w-full rounded border border-gray-300 px-2 py-1 text-xs">
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold">Age</label>
                                    <input type="number" name="age" class="w-full rounded border border-gray-300 px-2 py-1 text-xs" required>
                                </div>
                            </div>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                                <div>
                                    <label class="block text-xs font-semibold">Sex</label>
                                    <select name="sex" class="w-full rounded border border-gray-300 px-2 py-1 text-xs" required>
                                        <option value="">Select</option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold">Civil Status</label>
                                    <input type="text" name="civil_status" class="w-full rounded border border-gray-300 px-2 py-1 text-xs">
                                </div>
                            </div>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                                <div>
                                    <label class="block text-xs font-semibold">Cellphone No.</label>
                                    <input type="text" name="cellphone_no" class="w-full rounded border border-gray-300 px-2 py-1 text-xs">
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold">Tel. No.</label>
                                    <input type="text" name="tel_no" class="w-full rounded border border-gray-300 px-2 py-1 text-xs">
                                </div>
                            </div>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                                <div>
                                    <label class="block text-xs font-semibold">Address</label>
                                    <input type="text" name="address" class="w-full rounded border border-gray-300 px-2 py-1 text-xs">
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold">Position/Program/Campus</label>
                                    <input type="text" name="program" class="w-full rounded border border-gray-300 px-2 py-1 text-xs">
                                </div>
                            </div>
                        </div>

                        <!-- Medical & Family History - Physician Only -->
                        <div class="physician-only disabled-overlay rounded-lg p-6 mb-8">
                            <h3 class="text-lg font-bold text-blue-700 mb-4 disabled-label">Medical & Family History (For Physician Use Only)</h3>
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-4">
                                <div>
                                    <label class="block text-xs font-semibold disabled-label">Past Medical History</label>
                                    <textarea name="past_medical_history" class="w-full rounded border border-gray-300 px-2 py-1 text-xs physician-only" rows="2" readonly></textarea>
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold disabled-label">Family History</label>
                                    <textarea name="family_history" class="w-full rounded border border-gray-300 px-2 py-1 text-xs physician-only" rows="2" readonly></textarea>
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold disabled-label">Occupational History</label>
                                    <textarea name="occupational_history" class="w-full rounded border border-gray-300 px-2 py-1 text-xs physician-only" rows="2" readonly></textarea>
                                </div>
                            </div>
                        </div>

                        <!-- Physical Examination (Review of System) - Physician Only -->
                        <div class="physician-only disabled-overlay rounded-lg p-6 mb-8">
                            <h3 class="text-lg font-bold text-blue-700 mb-4 disabled-label">Physical Examination / Review of System (For Physician Use Only)</h3>
                            <div class="overflow-x-auto mb-4">
                                <table class="min-w-full border border-gray-300 text-xs text-center">
                                    <thead class="bg-gray-100">
                                        <tr>
                                            <th>System</th>
                                            <th>Normal</th>
                                            <th>Findings</th>
                                            <th>System</th>
                                            <th>Normal</th>
                                            <th>Findings</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>General Appearance/Body Built (BMI)</td><td><input type="checkbox" name="bmi_normal" class="physician-only" disabled></td><td><input type="text" name="bmi_findings" class="w-full border rounded px-1 physician-only" readonly></td>
                                            <td>Chest, Breast, Axilla</td><td><input type="checkbox" name="chest_normal" class="physician-only" disabled></td><td><input type="text" name="chest_findings" class="w-full border rounded px-1 physician-only" readonly></td>
                                        </tr>
                                        <tr>
                                            <td>Skin (Tattoo)</td><td><input type="checkbox" name="skin_normal" class="physician-only" disabled></td><td><input type="text" name="skin_findings" class="w-full border rounded px-1 physician-only" readonly></td>
                                            <td>Heart</td><td><input type="checkbox" name="heart_normal" class="physician-only" disabled></td><td><input type="text" name="heart_findings" class="w-full border rounded px-1 physician-only" readonly></td>
                                        </tr>
                                        <tr>
                                            <td>Head and Scalp</td><td><input type="checkbox" name="head_normal" class="physician-only" disabled></td><td><input type="text" name="head_findings" class="w-full border rounded px-1 physician-only" readonly></td>
                                            <td>Lungs</td><td><input type="checkbox" name="lungs_normal" class="physician-only" disabled></td><td><input type="text" name="lungs_findings" class="w-full border rounded px-1 physician-only" readonly></td>
                                        </tr>
                                        <tr>
                                            <td>Eyes (External)</td><td><input type="checkbox" name="eyes_normal" class="physician-only" disabled></td><td><input type="text" name="eyes_findings" class="w-full border rounded px-1 physician-only" readonly></td>
                                            <td>Abdomen</td><td><input type="checkbox" name="abdomen_normal" class="physician-only" disabled></td><td><input type="text" name="abdomen_findings" class="w-full border rounded px-1 physician-only" readonly></td>
                                        </tr>
                                        <tr>
                                            <td>Ears (Piercing)</td><td><input type="checkbox" name="ears_normal" class="physician-only" disabled></td><td><input type="text" name="ears_findings" class="w-full border rounded px-1 physician-only" readonly></td>
                                            <td>Anus, Rectum</td><td><input type="checkbox" name="anus_normal" class="physician-only" disabled></td><td><input type="text" name="anus_findings" class="w-full border rounded px-1 physician-only" readonly></td>
                                        </tr>
                                        <tr>
                                            <td>Nose and Throat</td><td><input type="checkbox" name="nose_normal" class="physician-only" disabled></td><td><input type="text" name="nose_findings" class="w-full border rounded px-1 physician-only" readonly></td>
                                            <td>Genital</td><td><input type="checkbox" name="genital_normal" class="physician-only" disabled></td><td><input type="text" name="genital_findings" class="w-full border rounded px-1 physician-only" readonly></td>
                                        </tr>
                                        <tr>
                                            <td>Mouth</td><td><input type="checkbox" name="mouth_normal" class="physician-only" disabled></td><td><input type="text" name="mouth_findings" class="w-full border rounded px-1 physician-only" readonly></td>
                                            <td>Musculo-Skeletal</td><td><input type="checkbox" name="musculo_normal" class="physician-only" disabled></td><td><input type="text" name="musculo_findings" class="w-full border rounded px-1 physician-only" readonly></td>
                                        </tr>
                                        <tr>
                                            <td>Neck, Thyroid, LN</td><td><input type="checkbox" name="neck_normal" class="physician-only" disabled></td><td><input type="text" name="neck_findings" class="w-full border rounded px-1 physician-only" readonly></td>
                                            <td>Extremities</td><td><input type="checkbox" name="extremities_normal" class="physician-only" disabled></td><td><input type="text" name="extremities_findings" class="w-full border rounded px-1 physician-only" readonly></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- Diagnostic Examination - Physician Only -->
                        <div class="physician-only disabled-overlay rounded-lg p-6 mb-8">
                            <h3 class="text-lg font-bold text-blue-700 mb-4 disabled-label">Diagnostic Examination (For Physician Use Only)</h3>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                                <div>
                                    <label class="block text-xs font-semibold disabled-label">Blood Pressure</label>
                                    <input type="text" name="blood_pressure" class="w-full rounded border border-gray-300 px-2 py-1 text-xs physician-only" readonly>
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold disabled-label">Heart Rate</label>
                                    <input type="text" name="heart_rate" class="w-full rounded border border-gray-300 px-2 py-1 text-xs physician-only" readonly>
                                </div>
                            </div>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                                <div>
                                    <label class="block text-xs font-semibold disabled-label">Hearing</label>
                                    <div class="flex gap-4">
                                        <label class="flex items-center gap-1 text-xs cursor-not-allowed"><input type="radio" name="hearing" value="Normal" class="physician-only" disabled> Normal</label>
                                        <label class="flex items-center gap-1 text-xs cursor-not-allowed"><input type="radio" name="hearing" value="Defective" class="physician-only" disabled> Defective</label>
                                    </div>
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold disabled-label">Vision</label>
                                    <div class="flex gap-4">
                                        <label class="flex items-center gap-1 text-xs cursor-not-allowed"><input type="checkbox" name="vision_glasses" class="physician-only" disabled> With glasses</label>
                                        <label class="flex items-center gap-1 text-xs cursor-not-allowed"><input type="checkbox" name="vision_without_glasses" class="physician-only" disabled> Without glasses</label>
                                    </div>
                                    <div class="flex gap-4 mt-2">
                                        <label class="block text-xs font-semibold disabled-label">R:</label>
                                        <input type="text" name="vision_r" class="w-20 rounded border border-gray-300 px-2 py-1 text-xs physician-only" readonly>
                                        <label class="block text-xs font-semibold disabled-label">L:</label>
                                        <input type="text" name="vision_l" class="w-20 rounded border border-gray-300 px-2 py-1 text-xs physician-only" readonly>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Certification - Mixed Sections -->
                        <div class="rounded-lg p-6 mb-8">
                            <h3 class="text-lg font-bold text-blue-700 mb-4">Certification</h3>
                            
                            <!-- Student Section -->
                            <div class="student-section rounded-lg p-4 mb-6">
                                <h4 class="text-md font-bold text-blue-600 mb-3">Student Information</h4>
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                                    <div>
                                        <label class="block text-xs font-semibold">School/Company/Institution</label>
                                        <input type="text" name="school_company" class="w-full rounded border border-gray-300 px-2 py-1 text-xs">
                                        <label class="block text-xs font-semibold mt-2">Weight (kg)</label>
                                        <input type="text" name="weight_cert" class="w-full rounded border border-gray-300 px-2 py-1 text-xs">
                                        <label class="block text-xs font-semibold mt-2">Height (cm)</label>
                                        <input type="text" name="height_cert" class="w-full rounded border border-gray-300 px-2 py-1 text-xs">
                                        <label class="block text-xs font-semibold mt-2">Civil Status</label>
                                        <input type="text" name="civil_status_cert" class="w-full rounded border border-gray-300 px-2 py-1 text-xs">
                                        <label class="block text-xs font-semibold mt-2">Date of Examination</label>
                                        <input type="date" name="date_cert" class="w-full rounded border border-gray-300 px-2 py-1 text-xs" value="<?php echo date('Y-m-d'); ?>">
                                    </div>
                                    <div class="flex flex-col items-center justify-center">
                                        <label class="block text-xs font-semibold mb-2">Attach picture here</label>
                                        <div class="w-32 h-32 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center bg-gray-50">
                                            <span class="text-xs text-gray-500">No Image</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Physician Only Section -->
                            <div class="physician-only disabled-overlay rounded-lg p-4 mb-6">
                                <h4 class="text-md font-bold text-blue-600 mb-3 disabled-label">Medical Assessment (For Physician Use Only)</h4>
                                <div class="mb-4 text-xs text-gray-700">I certify that I have examined and found the applicant to be physically fit/unfit for employment.</div>
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                                    <div>
                                        <label class="block text-xs font-semibold disabled-label">Classification</label>
                                        <div class="flex flex-col gap-2">
                                            <label class="flex items-center gap-1 text-xs cursor-not-allowed"><input type="checkbox" name="class_a" class="physician-only" disabled> Class A - Physically fit to work</label>
                                            <label class="flex items-center gap-1 text-xs cursor-not-allowed"><input type="checkbox" name="class_b" class="physician-only" disabled> Class B - Physically underdeveloped or with correctable defects but otherwise fit to work</label>
                                            <label class="flex items-center gap-1 text-xs cursor-not-allowed"><input type="checkbox" name="class_c" class="physician-only" disabled> Class C - Employable but owing to certain impairments or conditions, requires special placement or limited duty in a specified or selected assignment requiring follow up treatment/periodic evaluation</label>
                                            <label class="flex items-center gap-1 text-xs cursor-not-allowed"><input type="checkbox" name="class_d" class="physician-only" disabled> Class D - Unfit or unsafe for any type of employment</label>
                                        </div>
                                    </div>
                                    <div>
                                        <label class="block text-xs font-semibold disabled-label">Needs treatment or operation for:</label>
                                        <div class="flex flex-col gap-2">
                                            <label class="flex items-center gap-1 text-xs cursor-not-allowed"><input type="checkbox" name="skin_disease" class="physician-only" disabled> Skin Disease</label>
                                            <label class="flex items-center gap-1 text-xs cursor-not-allowed"><input type="checkbox" name="dental_defects" class="physician-only" disabled> Dental Defects</label>
                                            <label class="flex items-center gap-1 text-xs cursor-not-allowed"><input type="checkbox" name="anemia" class="physician-only" disabled> Anemia</label>
                                            <label class="flex items-center gap-1 text-xs cursor-not-allowed"><input type="checkbox" name="poor_vision" class="physician-only" disabled> Poor Vision</label>
                                            <label class="flex items-center gap-1 text-xs cursor-not-allowed"><input type="checkbox" name="mild_urinary" class="physician-only" disabled> Mild Urinary Tract Infection</label>
                                            <label class="flex items-center gap-1 text-xs cursor-not-allowed"><input type="checkbox" name="intestinal_parasite" class="physician-only" disabled> Intestinal Parasitism</label>
                                            <label class="flex items-center gap-1 text-xs cursor-not-allowed"><input type="checkbox" name="mild_hypertension" class="physician-only" disabled> Mild Hypertension</label>
                                            <label class="flex items-center gap-1 text-xs cursor-not-allowed"><input type="checkbox" name="others" class="physician-only" disabled> Others, specify: <input type="text" name="others_specify" class="w-32 rounded border border-gray-300 px-2 py-1 text-xs physician-only" readonly></label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Signatures Section -->
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                                <!-- Student Signature -->
                                <div class="student-section rounded-lg p-4">
                                    <label class="block text-xs font-semibold">Signature over Printed Name of Employee/Student</label>
                                    <input type="text" name="student_signature" class="w-full rounded border border-gray-300 px-2 py-1 text-xs" required>
                                </div>
                                <!-- Physician Signature -->
                                <div class="physician-only disabled-overlay rounded-lg p-4">
                                    <label class="block text-xs font-semibold disabled-label">Signature over Printed Name of Attending Physician</label>
                                    <input type="text" name="physician_name" class="w-full rounded border border-gray-300 px-2 py-1 text-xs physician-only" readonly>
                                    <label class="block text-xs font-semibold mt-2 disabled-label">License No.</label>
                                    <input type="text" name="license_no" class="w-full rounded border border-gray-300 px-2 py-1 text-xs physician-only" readonly>
                                    <label class="block text-xs font-semibold mt-2 disabled-label">Date</label>
                                    <input type="date" name="physician_date" class="w-full rounded border border-gray-300 px-2 py-1 text-xs physician-only" value="<?php echo date('Y-m-d'); ?>" readonly>
                                </div>
                            </div>
                        </div>

                        <!-- Data Privacy Act Notice -->
                        <div class="border-2 border-red-400 rounded-lg bg-white shadow p-4 mb-6">
                            <p class="text-xs text-gray-600 mb-2">Pursuant to Republic Act No. 10173, also known as the Data Privacy Act of 2012, the Batangas State University, the National Engineering University, recognizes its commitment to protect and respect the privacy of its customers and/or stakeholders and ensure that all information collected from them are all processed in accordance with the principles of transparency, legitimate purpose and proportionality mandated under the Data Privacy Act of 2012.</p>
                            <p class="text-xs text-gray-600 mb-2">This certificate does not cover conditions or diseases that will require procedure and examination for their detection and also those which are asymptomatic at the time of examination. Valid only for three (3) months from the date of examination.</p>
                        </div>
                        <div class="flex flex-col md:flex-row gap-4 justify-end mt-8">
                            <button type="submit" class="bg-blue-600 text-white font-semibold px-6 py-2 rounded-lg shadow hover:bg-blue-700 transition">Save Form</button>
                            <button type="button" class="bg-gray-400 text-white font-semibold px-6 py-2 rounded-lg shadow hover:bg-gray-500 transition" onclick="window.print()">Print Form</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script src="../../assets/js/jquery.min.js"></script>
    <script src="../../assets/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function() {
            // Prevent interaction with physician-only sections
            $('.physician-only').on('click focus', function(e) {
                e.preventDefault();
                $(this).blur();
                return false;
            });
        });
    </script>
    
    <?php if (!empty($success_message)): ?>
    <script>
        alert("Medical examination form successfully submitted! Please wait for admin verification.");
        window.location.href = "/capstone(foreal this time)/user_dashboard.php";
    </script>
    <?php endif; ?>
</body>
</html>