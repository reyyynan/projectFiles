<footer class="bg-light py-3 mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <p class="mb-0">&copy; <?php echo date('Y'); ?> Batangas State University - Clinic Record Management System</p>
            </div>
            <div class="col-md-6 text-end">
                <p class="mb-0">Pursuant to Republic Act No. 10173 (Data Privacy Act of 2012)</p>
            </div>
        </div>
    </div>
</footer>